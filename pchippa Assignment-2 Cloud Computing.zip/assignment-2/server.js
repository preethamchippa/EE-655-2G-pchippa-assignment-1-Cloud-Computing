const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require("mongodb");

const app = express();
const PORT = 3000;
const dbName = "blog";
const collectionName = "posts";

// Middleware
app.use(bodyParser.json());

// MongoDB URI
const uri = "mongodb://localhost:27017/" + dbName;

// Creating a MongoDB client
const client = new MongoClient(uri);

// Connect to the database
async function connectToDatabase() {
    try {
        await client.connect();
        console.log("Connected to MongoDB ...");
    } catch (error) {
        console.error("Error connecting to MongoDB:", error);
        process.exit(1); // Exit the process if connection fails
    }
}


app.post('/posts', async (req, res) => {
    const db = client.db();
    const collection = db.collection(collectionName);
    try {
        const { title, content, username } = req.body;
        const result = await collection.insertOne({ title, content, username });
        if (result.acknowledged) {
            res.status(200).json({ 'message': 'Post added successfully' });
        } else {
            res.status(400).send('Adding new post failed');
        }
    } catch (err) {
        console.error("Error adding new post:", err);
        res.status(500).send('Adding new post failed');
    }
});
// Routes
app.get('/posts', async (req, res) => {
    const db = client.db();
    const collection = db.collection(collectionName);
    try {
        const posts = await collection.find({}).toArray();
        res.json(posts);
    } catch (err) {
        console.error("Error fetching posts:", err);
        res.status(500).send("Failed to fetch posts.");
    }
});
// Route to retrieve all posts by a given username
app.get('/posts/:username', async (req, res) => {
    const requestedUsername = req.params.username;
    const db = client.db();
    const collection = db.collection(collectionName);
    try {
        const posts = await collection.find({ username: requestedUsername }).toArray();
        res.json(posts);
    } catch (err) {
        console.error("Error fetching posts:", err);
        res.status(500).send("Failed to fetch posts.");
    }
});

// Route to retrieve all posts containing a given word in the title
app.get('/posts/search/word', async (req, res) => {
    const searchWord = req.query.searchWord;
    const db = client.db();
    const collection = db.collection(collectionName);
    try {
        const posts = await collection.find({ title: { $regex: searchWord, $options: 'i' } }).toArray();
        res.json(posts);
    } catch (err) {
        console.error("Error fetching posts:", err);
        res.status(500).send("Failed to fetch posts.");
    }
});

// Route to retrieve all posts containing a given word in the content
app.get('/posts/search/content', async (req, res) => {
    const searchWord = req.query.searchWord;
    const db = client.db();
    const collection = db.collection(collectionName);
    try {
        const posts = await collection.find({ content: { $regex: searchWord, $options: 'i' } }).toArray();
        res.json(posts);
    } catch (err) {
        console.error("Error fetching posts:", err);
        res.status(500).send("Failed to fetch posts.");
    }
});
// Route to delete all posts by a given username
app.delete('/posts/:username', async (req, res) => {
    const usernameToDelete = req.params.username;
    const db = client.db();
    const collection = db.collection(collectionName);
    try {
        const result = await collection.deleteMany({ username: usernameToDelete });
        if (result.deletedCount > 0) {
            res.status(200).json({ message: `Deleted ${result.deletedCount} posts for username ${usernameToDelete}` });
        } else {
            res.status(404).json({ message: `No posts found for username ${usernameToDelete}` });
        }
    } catch (err) {
        console.error("Error deleting posts:", err);
        res.status(500).send("Failed to delete posts.");
    }
});

// Route to delete all posts containing a certain word in the title or content
app.delete('/posts/search/:searchWord', async (req, res) => {
    const searchWord = req.params.searchWord;
    const db = client.db();
    const collection = db.collection(collectionName);
    try {
        const result = await collection.deleteMany({
            $or: [
                { title: { $regex: searchWord, $options: 'i' } },
                { content: { $regex: searchWord, $options: 'i' } }
            ]
        });
        if (result.deletedCount > 0) {
            res.status(200).json({ message: `Deleted ${result.deletedCount} posts containing the word '${searchWord}'` });
        } else {
            res.status(404).json({ message: `No posts found containing the word '${searchWord}'` });
        }
    } catch (err) {
        console.error("Error deleting posts:", err);
        res.status(500).send("Failed to delete posts.");
    }
});

// Route to get the username and the number of blog posts posted by that username
app.get('/posts/countByUser/count', async (req, res) => {
    const db = client.db();
    const collection = db.collection(collectionName);
    try {
        const result = await collection.aggregate([
            { $group: { _id: "$username", count: { $sum: 1 } } },
            { $project: { _id: 0, username: "$_id", count: 1 } }
        ]).toArray();
        res.json(result);
    } catch (err) {
        console.error("Error fetching post counts by user:", err);
        res.status(500).send("Failed to fetch post counts by user.");
    }
});

// Start the server
app.listen(PORT, async () => {
    console.log(`Connected to the Express server on port ${PORT}`);
    await connectToDatabase();
});
