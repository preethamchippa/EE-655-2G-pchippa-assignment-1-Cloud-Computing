// JavaScript code for handling client-side interactions

// Register form submission
document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            const deviceIdInput = document.getElementById('deviceId');
            const deviceTypeInput = document.getElementById('deviceType');

            if (!deviceIdInput || !deviceTypeInput) {
                alert('Device ID and Device Type inputs are missing.');
                return;
            }

            const deviceId = deviceIdInput.value;
            const deviceType = deviceTypeInput.value;
            
            const response = await fetch('/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ deviceId, deviceType })
            });
            const result = await response.json();
            if (result.success) {
                alert('Device registered successfully!');
                displayDevices(); // Display updated list of devices
            } else {
                alert('Failed to register device. ' + result.message); // Display the error message from the server
            }
        });
    }
});

// Command form submission
const commandForm = document.getElementById('commandForm');
if (commandForm) {
    commandForm.addEventListener('submit', async function(event) {
        event.preventDefault();
        const deviceId = document.getElementById('commandDeviceId').value;
        const command = document.getElementById('command').value;
        // Check if both deviceId and command are not empty
        if (!deviceId || !command) {
            alert('Device ID and Command inputs are missing.');
            return;
        }
        // Send the command to the server
        try {
            const response = await fetch('/command', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ deviceId, command })
            });
            if (response.ok) {
                alert('Command sent successfully!');
                // Optionally, update the UI or perform actions based on command response
            } else {
                // If the server responds with an error status, show an error message
                const errorData = await response.json();
                alert(`Failed to send command: ${errorData.message}`);
            }
        } catch (error) {
            console.error('Error sending command:', error);
            alert('Failed to send command. Please try again.');
        }
    });
}

// Function to send data to the server
const dataForm = document.getElementById('dataForm');
if (dataForm) {
    dataForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        const deviceId = document.getElementById('deviceId').value;
        const data = document.getElementById('data').value;

        fetch('/data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ deviceId, data })
        })
        .then(response => {
            if (response.ok) {
                alert('Data sent successfully!');
                // Optionally, update the UI or perform actions based on data response
            } else {
                alert('Failed to send data. Please try again.');
            }
        })
        .catch(error => {
            console.error('Error sending data:', error);
            alert('Failed to send data. Please try again.');
        });
    });
}

// Function to send command to the server
function sendCommand() {
    const deviceId = document.getElementById('commandDeviceId').value;
    const command = document.getElementById('command').value;

    fetch('/command', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ deviceId, command })
    })
    .then(response => {
        if (response.ok) {
            alert('Command sent successfully!');
            // Optionally, update the UI or perform actions based on command response
        } else {
            alert('Failed to send command. Please try again.');
        }
    })
    .catch(error => {
        console.error('Error sending command:', error);
        alert('Failed to send command. Please try again.');
    });
}

