const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const app = express();

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Serve static files from the "public" directory
const publicDirectoryPath = path.join(__dirname, 'public');
app.use(express.static(publicDirectoryPath));

// Path to the devices.json file
const devicesFilePath = path.join(__dirname, 'devices.json');

// Ensure devices.json file exists, if not create it
fs.access(devicesFilePath, fs.constants.F_OK, (err) => {
    if (err) {
        console.log('Creating devices.json file...');
        fs.writeFileSync(devicesFilePath, '[]');
    }
});

// Dummy database to store registered devices
let registeredDevices = [];

// Task-2
app.get('/register', (req, res) => {
    // Path to the register.html file
    const registerFilePath = path.join(__dirname, 'public', 'index.html');
    
    res.sendFile(registerFilePath);
});

// Route for registering a new device
app.post('/register', (req, res) => {
    const { deviceId, deviceType } = req.body;

    // Validate the presence of deviceId and deviceType in the request body
    if (!deviceId || !deviceType) {
        return res.status(400).json({ success: false, message: 'Both deviceId and deviceType are required.' });
    }

    // Check if the device ID is already registered
    if (registeredDevices.some(device => device.deviceId === deviceId)) {
        return res.status(400).json({ success: false, message: 'Device already registered.' });
    }

    // Add the device to the list of registered devices
    registeredDevices.push({ deviceId, deviceType });

    // Save registered devices to devices.json
    fs.writeFile(devicesFilePath, JSON.stringify(registeredDevices), err => {
        if (err) {
            console.error('Error saving devices to file:', err);
            return res.status(500).json({ success: false, message: 'Failed to save devices to file.' });
        }
        logData('Registration', `Device registered successfully: ${deviceId}`);
        console.log('Devices saved to devices.json');
    });

    // Respond with a status code 201 for confirming successful registration
    return res.status(201).json({ success: true, message: 'Device registered successfully.' });
});

// Task-3  Route for showing all registered devices
app.get('/show', (req, res) => {
    // Read the registered devices from devices.json file
    fs.readFile(devicesFilePath, (err, data) => {
        if (err) {
            console.error('Error reading devices from file:', err);
            logData('Error', 'Failed to read devices from file.');
            return res.status(500).json({ success: false, message: 'Failed to read devices from file.' });
        }
        const devices = JSON.parse(data);
        return res.status(200).json({ success: true, devices });
    });
});

// Task-4
app.get('/data', (req, res) => {
    const dataFilePath = path.join(__dirname, 'public', 'index.html');
    
    res.sendFile(dataFilePath);
});

// Route for receiving data from devices
app.post('/data', (req, res) => {
    const { deviceId, data } = req.body;
    
    // Validate the presence of deviceId and data in the request body
    if (!deviceId || !data) {
        return res.status(400).json({ success: false, message: 'Both deviceId and data are required.' });
    }
    
    // Log the received data with a timestamp
    logData('Data Received', `Received data from device ${deviceId}: ${data}`);
    
    // Send response to client
    res.status(200).json({ success: true, message: 'Data received successfully.' });
});

// Task-5
app.get('/command', (req, res) => {
    const commandFilePath = path.join(__dirname, 'public', 'index.html');
    
    res.sendFile(commandFilePath);
});

// Route for sending commands to devices
app.post('/command', (req, res) => {
    const { deviceId, command } = req.body;
    
    // Validate the presence of deviceId and command in the request body
    if (!deviceId || !command) {
        return res.status(400).json({ success: false, message: 'Both deviceId and command are required.' });
    }

    // Log the received command with a timestamp
    logData('Command Received', `Received command for device ${deviceId}: ${command}`);
    
    res.status(200).json({ success: true, message: 'Command received successfully.' });
});

// Task -6 Log all activities with timestamps to logs.txt
function logData(activity, message) {
    const timestamp = new Date().toISOString();
    const logMessage = `${timestamp} - ${activity}: ${message}\n`;

    fs.appendFile('logs.txt', logMessage, (err) => {
        if (err) {
            console.error('Error logging data:', err);
        }
    });
}

// Bonus Task -7 Load existing devices from devices.json into memory on application startup
function loadDevices() {
    try {
        const data = fs.readFileSync(devicesFilePath, 'utf8'); // Specify encoding to read file as a string
        return JSON.parse(data);
    } catch (err) {
        console.error('Error loading devices:', err);
        return []; // Return an empty array if there's an error
    }
}

// Task-1 Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is up and running on port ${PORT}`);
    // Call the loadDevices function
    const devices = loadDevices();
    console.log('Loaded devices:', devices);// Load existing devices on startup
});
